from courses.models.course import Course , Learning , Prerequisite , Tag 
from courses.models.video import Video
from courses.models.user_course import UserCourse
from courses.models.payment import Payment